package org.disruptdelivery.base.service.interfaces;

import org.disruptdelivery.base.domain.Product;

import java.util.List;

public interface ProductSerInterface {

	List<Product> getAllProducts();

}
